from django.apps import AppConfig

class IcuConfig(AppConfig):
    name = 'icu'
