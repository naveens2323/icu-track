from django.contrib import admin
from .models import Patient, MonitorReading, Alert

admin.site.register(Patient)
admin.site.register(MonitorReading)
admin.site.register(Alert)
