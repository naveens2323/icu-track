from rest_framework import serializers
from .models import SensorData

def get_monitor_reading_serializer():
    from .models import MonitorReading  # Delayed import
    class MonitorReadingSerializer(serializers.ModelSerializer):
        class Meta:
            model = MonitorReading
            fields = '__all__'
    return MonitorReadingSerializer


class SensorDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = SensorData
        fields = '__all__'
