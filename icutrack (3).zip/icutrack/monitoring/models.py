from django.db import models

class Patient(models.Model):
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    dob = models.DateField()
    gender_choices = [('Male', 'Male'), ('Female', 'Female'), ('Other', 'Other')]
    gender = models.CharField(max_length=10, choices=gender_choices)
    admission_date = models.DateTimeField()
    discharge_date = models.DateTimeField(null=True, blank=True)
    bed_number = models.IntegerField()

    def __str__(self):
        return f"{self.first_name} {self.last_name}"

class VitalSigns(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    heart_rate = models.IntegerField()
    blood_pressure = models.CharField(max_length=10)
    respiratory_rate = models.IntegerField()
    temperature = models.DecimalField(max_digits=4, decimal_places=2)
    oxygen_level = models.DecimalField(max_digits=4, decimal_places=2)
    timestamp = models.DateTimeField()

    def __str__(self):
        return f"Vital signs for {self.patient} at {self.timestamp}"

class MedicalEquipment(models.Model):
    equipment_name = models.CharField(max_length=255)
    equipment_type = models.CharField(max_length=100)
    status_choices = [('Operational', 'Operational'), ('Non-Operational', 'Non-Operational'), ('Under Maintenance', 'Under Maintenance')]
    status = models.CharField(max_length=20, choices=status_choices)
    location = models.CharField(max_length=255)

    def __str__(self):
        return self.equipment_name

class EquipmentUsage(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    equipment = models.ForeignKey(MedicalEquipment, on_delete=models.CASCADE)
    usage_start = models.DateTimeField()
    usage_end = models.DateTimeField(null=True, blank=True)
    status_choices = [('In Use', 'In Use'), ('Completed', 'Completed')]
    status = models.CharField(max_length=20, choices=status_choices)

    def __str__(self):
        return f"Usage of {self.equipment} by {self.patient}"

class DoctorOrder(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor_name = models.CharField(max_length=255)
    order_description = models.TextField()
    order_date = models.DateTimeField()
    status_choices = [('Pending', 'Pending'), ('Completed', 'Completed'), ('Cancelled', 'Cancelled')]
    status = models.CharField(max_length=20, choices=status_choices)

    def __str__(self):
        return f"Order by {self.doctor_name} for {self.patient}"

class Medication(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    medication_name = models.CharField(max_length=255)
    dosage = models.CharField(max_length=100)
    frequency = models.CharField(max_length=100)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"Medication for {self.patient}: {self.medication_name}"

class NursesRecord(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    nurse_name = models.CharField(max_length=255)
    record_date = models.DateTimeField()
    nursing_notes = models.TextField()

    def __str__(self):
        return f"Record by {self.nurse_name} for {self.patient}"
