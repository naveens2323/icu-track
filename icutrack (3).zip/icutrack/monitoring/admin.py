from django.contrib import admin
from .models import Patient, VitalSigns, MedicalEquipment, EquipmentUsage, DoctorOrder, Medication, NursesRecord

admin.site.register(Patient)
admin.site.register(VitalSigns)
admin.site.register(MedicalEquipment)
admin.site.register(EquipmentUsage)
admin.site.register(DoctorOrder)
admin.site.register(Medication)
admin.site.register(NursesRecord)
