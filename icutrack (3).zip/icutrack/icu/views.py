from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import MonitorReading  # Import your model
from django.http import JsonResponse
from django.shortcuts import render
from .models import Patient
from .models import SensorData
from django.shortcuts import get_object_or_404
from datetime import datetime, timedelta

@csrf_exempt 
def receive_sensor_data(request):
    print(f"🔹 Request Method: {request.method}")
    print(f"🔹 Request Headers: {request.headers}")
    print(f"🔹 Raw Request Body: {request.body}")

    if request.method == "POST":
        try:
            data = json.loads(request.body.decode("utf-8"))
            print(f"✅ Received Data: {data}")  # Log received data

            return JsonResponse({"message": "Data received successfully"}, status=200)

        except json.JSONDecodeError:
            print("❌ JSON Decode Error!")
            return JsonResponse({"error": "Invalid JSON format"}, status=400)

    print("❌ Invalid Request Method!")
    return JsonResponse({"error": "Invalid request"}, status=400)

def get_live_data(request):
    patient_id = request.GET.get('patient_id')

    if not patient_id:
        return JsonResponse({'error': 'Patient ID is required'}, status=400)

    # Fetch latest 10 minutes of data for the selected patient
    time_threshold = datetime.now() - timedelta(minutes=10)
    sensor_entries = SensorData.objects.filter(patient_id=patient_id, timestamp__gte=time_threshold).order_by('timestamp')

    data = [
        {
            'timestamp': entry.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            'body_temperature': entry.body_temperature,
            'heart_rate': entry.heart_rate,
            'blood_oxygen': entry.blood_oxygen,
            'blood_pressure': entry.blood_pressure,
            'glucose_level': entry.glucose_level,
            'respiration_rate': entry.respiration_rate,
            'room_temperature': entry.room_temperature,
            'ecg_readings': entry.ecg_readings
        }
        for entry in sensor_entries
    ]

    return JsonResponse(data, safe=False)

def live_data(request):
    readings = MonitorReading.objects.order_by('-timestamp')[:10].values()
    return JsonResponse(list(readings), safe=False)

def live_monitor(request):
    return render(request, 'live_monitor.html')

def get_patients(request):
    patients = list(Patient.objects.values("id", "name", "age", "gender"))
    return JsonResponse(patients, safe=False)