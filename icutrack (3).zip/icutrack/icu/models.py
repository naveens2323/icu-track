from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=200)
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    room_number = models.CharField(max_length=50)
    admission_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class MonitorReading(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    temperature = models.FloatField()
    heart_rate = models.IntegerField()
    blood_pressure_systolic = models.IntegerField()
    blood_pressure_diastolic = models.IntegerField()
    respiratory_rate = models.IntegerField()
    blood_oxygen = models.IntegerField(default=98)
    blood_glucose = models.IntegerField(default=100)
    eeg_signal = models.IntegerField(default=50)
    co2_level = models.IntegerField(default=400)
    pm25_level = models.IntegerField(default=10)
    blood_ph = models.FloatField(default=7.4)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Reading for {self.patient.name} at {self.timestamp}"

class Alert(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    message = models.CharField(max_length=500)
    severity = models.CharField(max_length=50)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Alert for {self.patient.name}: {self.message}"
    

class SensorData(models.Model):
    patient_id = models.IntegerField()
    timestamp = models.DateTimeField(auto_now_add=True)
    body_temperature = models.FloatField()
    heart_rate = models.IntegerField()
    blood_oxygen = models.FloatField(null=True, blank=True)
    blood_pressure = models.CharField(max_length=10)  # e.g., "120/80"
    glucose_level = models.FloatField()
    respiration_rate = models.IntegerField()
    room_temperature = models.FloatField()
    ecg_readings = models.TextField()  # Store ECG readings as JSON/text

    def __str__(self):
        return f"Sensor Data for {self.patient} at {self.timestamp}"
