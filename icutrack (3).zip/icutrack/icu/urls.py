from django.urls import path
from .views import receive_sensor_data
from .views import live_data
from . import views
from .views import get_patients
from .views import get_live_data

urlpatterns = [
    path('receive-data/', receive_sensor_data, name='receive_data'),
    path('live-monitor/', views.live_monitor, name='live_monitor'),  # Live Monitoring Page
    path('api/live-data/', views.live_data, name='live_data'),
    path("api/patients/", get_patients, name="get_patients"),
    path('api/live-data/', get_live_data, name='live-data'),  # API to fetch live sensor data
]
